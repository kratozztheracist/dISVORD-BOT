const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabAdmin = require("playfab-sdk/Scripts/PlayFab/PlayFabAdmin");

const allowedRoles = [""]; 

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unbans a player in PlayFab.")
    .addStringOption((option) =>
      option
        .setName("userid")
        .setDescription("The PlayFab ID of the player to unban.")
        .setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const userid = interaction.options.getString("userid");

    try {
      const revokeBanResult = await PlayFabAdmin.RevokeAllBansForUser({
        PlayFabId: userid
      });

      const embed = new EmbedBuilder()
        .setTitle("Player Unbanned")
        .setDescription(`Successfully unbanned **${userid}**.`)
        .setColor(0x2ECC71) 
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error("Error unbanning user:", error);

      const errorEmbed = new EmbedBuilder()
        .setTitle("❌ Unban Failed")
        .setDescription(`An error occurred while unbanning **${userid}**.`)
        .addFields({ name: "Error", value: error.message || "Unknown error" })
        .setColor(0xE74C3C) 
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed] });
    }
  }
};
