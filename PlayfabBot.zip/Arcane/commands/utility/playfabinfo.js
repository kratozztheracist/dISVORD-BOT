const { SlashCommandBuilder } = require("discord.js");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");
const fs = require("fs");
const path = require("path");

const allowedRoles = [""];
const linkedFile = path.join(__dirname, "..", "data", "linkedAccounts.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("playfabinfo")
    .setDescription("View your PlayFab account info using your Discord account."),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(r => r.id);
    if (!allowedRoles.some(r => userRoles.includes(r))) {
      return interaction.reply({ content: "❌ You don't have the required role.", ephemeral: true });
    }

    // Load linkedAccounts.json
    let linkedAccounts = {};
    if (fs.existsSync(linkedFile)) {
      linkedAccounts = JSON.parse(fs.readFileSync(linkedFile, "utf-8"));
    }

    const discordId = interaction.member.id;
    const playFabId = Object.keys(linkedAccounts).find(key => linkedAccounts[key] === discordId);

    if (!playFabId) {
      return interaction.reply({ content: "⚠️ No linked PlayFab ID found for your account.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      // Fetch PlayFab Info
      const accountInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserAccountInfo({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const userInfo = accountInfo?.data?.UserInfo;
      if (!userInfo) throw new Error("User info missing in response.");

      const inventoryInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserInventory({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const banInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserBans({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const currency = inventoryInfo?.data?.VirtualCurrency || {};

      const bans = banInfo?.data?.BanData || [];
      const activeBan = bans.find(b => !b.Revoked);
      const banStatus = activeBan
        ? `🚫 BANNED — Reason: ${activeBan.Reason || "No reason provided"}`
        : "✅ Not Banned";

      const output = `📋 PlayFab Info for **${interaction.member.displayName}**

🆔 **PlayFab ID:** \`${playFabId}\`
📅 **Account Created:** ${new Date(userInfo.Created).toLocaleString()}
💰 **Shiny Rocks:** ${
        Object.entries(currency)
          .map(([c, a]) => `${c}: ${a.toLocaleString()}`)
          .join(", ") || "None"
      }
🔒 **Ban Status:** ${banStatus}
`;

      await interaction.editReply({ content: output });

    } catch (err) {
      console.error("PlayFab info error:", err);
      await interaction.editReply({ content: "❌ Failed to fetch PlayFab info." });
    }
  },
};
