const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");

const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");
const fs = require("fs");
const path = require("path");

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

const CURRENCY = "SR";
const ITEMS_PER_PAGE = 5;
const dataFile = path.join(__dirname, "..", "data", "linkedAccounts.json");

const blockedItems = ["LBAAK.", "LBAAD.", "LBADE.", "LBATS.", "LBAGS."];

function formatSR(amount) {
  return amount.toLocaleString("en-US");
}

const GIFT_COOLDOWN = 60 * 1000;
const giftCooldowns = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName("shop")
    .setDescription("browse and buy cosmetics with your shiny rocks!"),

  async execute(interaction) {
    await interaction.deferReply();

    let linkedAccounts = {};
    if (fs.existsSync(dataFile)) {
      try {
        linkedAccounts = JSON.parse(fs.readFileSync(dataFile, "utf8"));
      } catch (e) {
        console.error("Error reading linkedAccounts.json:", e);
      }
    }

    const discordId = interaction.user.id;
    const playFabId = Object.keys(linkedAccounts).find(
      (id) => linkedAccounts[id] === discordId,
    );

    if (!playFabId)
      return interaction.editReply(
        "⚠️ You do not have a linked PlayFab account.",
      );

    // Inventory
    const inv = await new Promise((resolve, reject) => {
      PlayFabServer.GetUserInventory({ PlayFabId: playFabId }, (err, res) =>
        err ? reject(err) : resolve(res),
      );
    });

    let ownedItems = (inv.data.Inventory || []).map((i) => i.ItemId);
    let balance = inv.data.VirtualCurrency?.[CURRENCY] || 0;

    // Catalog
    const catalog = await new Promise((resolve, reject) => {
      PlayFabServer.GetCatalogItems({ CatalogVersion: "DLC" }, (err, res) =>
        err ? reject(err) : resolve(res),
      );
    });

    const allItems = catalog.data.Catalog || [];

    let purchasable = allItems.filter(
      (i) =>
        i.VirtualCurrencyPrices &&
        i.VirtualCurrencyPrices[CURRENCY] &&
        !blockedItems.includes(i.ItemId),
    );

    let page = 0;

    const totalPages = () =>
      Math.max(1, Math.ceil(purchasable.length / ITEMS_PER_PAGE));

    // ---------------------------
    // MODERN EMBED (REPLACED)
    // ---------------------------
    const generateEmbed = () => {
      const start = page * ITEMS_PER_PAGE;
      const pageItems = purchasable.slice(start, start + ITEMS_PER_PAGE);

      const embed = new EmbedBuilder()
        .setColor(0x2b2d31)
        .setTitle("🛒 Cosmetic Shop")
        .setDescription(
          [
            `🆔 **Player ID:** \`${playFabId}\``,
            `💰 **Balance:** **${formatSR(balance)} Shiny Rocks**`,
            ``,
            `Browse and buy cosmetics with your **Shiny Rocks**`,
            ``,
            `**Page ${page + 1} / ${totalPages()}**`,
            `──────────────────────────`,
          ].join("\n"),
        )
        .setTimestamp();

      if (pageItems.length === 0) {
        embed.addFields({
          name: "No Results",
          value: "Try adjusting your search.",
        });
        return embed;
      }

      pageItems.forEach((item) => {
        const name = item.DisplayName || item.ItemId;
        const price = formatSR(item.VirtualCurrencyPrices[CURRENCY]);

        // Each item is its own neat block
        embed.addFields({
          name: `🎨 **${name}**`,
          value: [
            `> 🆔 **ID:** \`${item.ItemId}\``,
            `> 💵 **Price:** **${price} Shiny Rocks**`,
            `──────────────────────────`,
          ].join("\n"),
        });
      });

      return embed;
    };

    // ---------------------------
    // MODERN BUTTONS (REPLACED)
    // One row for nav + one row per item (kept within Discord limits)
    // ---------------------------
    const makeButtons = (owned) => {
      const rows = [];

      // Row 1 — Navigation
      rows.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("prev")
            .setLabel("◀ Previous")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === 0),

          new ButtonBuilder()
            .setCustomId("search")
            .setLabel("🔍 Search")
            .setStyle(ButtonStyle.Primary),

          new ButtonBuilder()
            .setCustomId("gift")
            .setLabel("🎁 Gift")
            .setStyle(ButtonStyle.Primary),

          new ButtonBuilder()
            .setCustomId("next")
            .setLabel("Next ▶")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === totalPages() - 1)
        )
      );

      // Row 2 — All Buy buttons together
      const buyRow = new ActionRowBuilder();
      const start = page * ITEMS_PER_PAGE;
      const pageItems = purchasable.slice(start, start + ITEMS_PER_PAGE);

      pageItems.forEach((item) => {
        const isOwned = owned.includes(item.ItemId);

        buyRow.addComponents(
          new ButtonBuilder()
            .setCustomId(`buy_${item.ItemId}`)
            .setLabel(
              isOwned
                ? "Owned"
                : `Buy ${item.DisplayName?.substring(0, 20) || item.ItemId}`
            )
            .setStyle(isOwned ? ButtonStyle.Secondary : ButtonStyle.Success)
            .setDisabled(isOwned)
        );
      });

      rows.push(buyRow);

      return rows;
    };


    const message = await interaction.editReply({
      embeds: [generateEmbed()],
      components: makeButtons(ownedItems),
    });

    const collector = message.createMessageComponentCollector({
      time: 5 * 60 * 1000,
    });

    const modalListener = async (modal) => {
      if (!modal.isModalSubmit()) return;
      if (modal.user.id !== interaction.user.id) return;

      // SEARCH
      if (modal.customId === "search_modal") {
        const query = modal.fields.getTextInputValue("query").toLowerCase();

        purchasable = allItems.filter(
          (i) =>
            i.VirtualCurrencyPrices &&
            i.VirtualCurrencyPrices[CURRENCY] &&
            !blockedItems.includes(i.ItemId) &&
            (i.ItemId.toLowerCase().includes(query) ||
              (i.DisplayName && i.DisplayName.toLowerCase().includes(query))),
        );

        page = 0;

        return modal.update({
          embeds: [generateEmbed()],
          components: makeButtons(ownedItems),
        });
      }

      // GIFT
      if (modal.customId === "gift_modal") {
        const recipientInputRaw = modal.fields
          .getTextInputValue("recipient")
          .trim();
        const giftItemId = modal.fields.getTextInputValue("gift_item").trim();

        let recipientPlayFabId = null;
        let recipientDiscordId = null;

        const mentionMatch = recipientInputRaw.match(/^<@!?(\d+)>$/);
        if (mentionMatch) {
          recipientDiscordId = mentionMatch[1];
          recipientPlayFabId = Object.keys(linkedAccounts).find(
            (k) => linkedAccounts[k] === recipientDiscordId,
          );
        } else if (/^\d{17,20}$/.test(recipientInputRaw)) {
          const mapped = Object.keys(linkedAccounts).find(
            (k) => linkedAccounts[k] === recipientInputRaw,
          );
          if (mapped) {
            recipientPlayFabId = mapped;
            recipientDiscordId = recipientInputRaw;
          } else recipientPlayFabId = recipientInputRaw;
        } else {
          recipientPlayFabId = recipientInputRaw;
        }

        if (recipientDiscordId === interaction.user.id)
          return modal.reply({
            content: `❌ You cannot gift items to yourself.`,
            ephemeral: true,
          });

        if (recipientPlayFabId === playFabId)
          return modal.reply({
            content: `❌ You cannot gift items to yourself.`,
            ephemeral: true,
          });

        const now = Date.now();
        const cooldownEnds = giftCooldowns.get(interaction.user.id) || 0;

        if (cooldownEnds > now) {
          const remaining = Math.ceil((cooldownEnds - now) / 1000);
          return modal.reply({
            content: `⏳ You must wait **${remaining}s** before gifting again.`,
            ephemeral: true,
          });
        }

        const item = allItems.find((i) => i.ItemId === giftItemId);
        if (
          !item ||
          !item.VirtualCurrencyPrices ||
          !item.VirtualCurrencyPrices[CURRENCY] ||
          blockedItems.includes(giftItemId)
        ) {
          return modal.reply({
            content: `❌ Item "${giftItemId}" not found or not purchasable.`,
            ephemeral: true,
          });
        }

        const cost = item.VirtualCurrencyPrices[CURRENCY];

        if (!recipientPlayFabId)
          return modal.reply({
            content: `❌ Could not resolve recipient.`,
            ephemeral: true,
          });

        try {
          const recipientInv = await new Promise((resolve, reject) => {
            PlayFabServer.GetUserInventory(
              { PlayFabId: recipientPlayFabId },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          const recipientOwned = (recipientInv.data.Inventory || []).map(
            (i) => i.ItemId,
          );

          if (recipientOwned.includes(giftItemId))
            return modal.reply({
              content: `❌ Recipient already owns **${giftItemId}**.`,
              ephemeral: true,
            });

          const senderInv = await new Promise((resolve, reject) => {
            PlayFabServer.GetUserInventory(
              { PlayFabId: playFabId },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          const senderBalance = senderInv.data.VirtualCurrency?.[CURRENCY] || 0;

          if (senderBalance < cost)
            return modal.reply({
              content: `❌ Not enough SR.\nCost: ${formatSR(
                cost,
              )} | You have: ${formatSR(senderBalance)}`,
              ephemeral: true,
            });

          await new Promise((resolve, reject) => {
            PlayFabServer.SubtractUserVirtualCurrency(
              {
                PlayFabId: playFabId,
                VirtualCurrency: CURRENCY,
                Amount: cost,
              },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          await new Promise((resolve, reject) => {
            PlayFabServer.GrantItemsToUser(
              {
                PlayFabId: recipientPlayFabId,
                ItemIds: [giftItemId],
                CatalogVersion: "DLC",
              },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          giftCooldowns.set(interaction.user.id, now + GIFT_COOLDOWN);

          const updatedSenderInv = await new Promise((resolve, reject) => {
            PlayFabServer.GetUserInventory(
              { PlayFabId: playFabId },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          ownedItems = (updatedSenderInv.data.Inventory || []).map(
            (i) => i.ItemId,
          );
          balance = updatedSenderInv.data.VirtualCurrency?.[CURRENCY] || 0;

          try {
            await message.edit({
              embeds: [generateEmbed()],
              components: makeButtons(ownedItems),
            });
          } catch {}

          const recipientLabel = recipientDiscordId
            ? `<@${recipientDiscordId}>`
            : `PlayFabId: \`${recipientPlayFabId}\``;

          return modal.reply({
            content: `✅ Gifted **${giftItemId}** to ${recipientLabel} for **${formatSR(
              cost,
            )} SR**.`,
            ephemeral: true,
          });
        } catch (err) {
          console.error("Gift error:", err);
          return modal.reply({
            content: `❌ Error while gifting: ${err.message}`,
            ephemeral: true,
          });
        }
      }
    };

    interaction.client.on("interactionCreate", modalListener);

    // BUTTON HANDLING
    collector.on("collect", async (btn) => {
      if (btn.user.id !== interaction.user.id)
        return btn.reply({
          content: "This is not your shop session.",
          ephemeral: true,
        });

      const id = btn.customId;

      // Shop pagination
      if (id === "prev") page = Math.max(0, page - 1);
      if (id === "next") page = Math.min(totalPages() - 1, page + 1);

      // Search
      if (id === "search") {
        const modal = new ModalBuilder()
          .setCustomId("search_modal")
          .setTitle("Search Shop");

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("query")
              .setLabel("Search term:")
              .setRequired(true)
              .setStyle(TextInputStyle.Short),
          ),
        );

        return btn.showModal(modal);
      }

      // Gift
      if (id === "gift") {
        const modal = new ModalBuilder()
          .setCustomId("gift_modal")
          .setTitle("Gift an Item");

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("recipient")
              .setLabel("Recipient (Discord mention/ID or PlayFabId)")
              .setRequired(true)
              .setStyle(TextInputStyle.Short),
          ),
        );

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("gift_item")
              .setLabel("Item ID to gift (exact)")
              .setRequired(true)
              .setStyle(TextInputStyle.Short),
          ),
        );

        return btn.showModal(modal);
      }

      // Buying
      if (id.startsWith("buy_")) {
        const itemId = id.replace("buy_", "");
        const item = purchasable.find((i) => i.ItemId === itemId);
        const cost = item.VirtualCurrencyPrices[CURRENCY];

        try {
          const invBuy = await new Promise((resolve, reject) => {
            PlayFabServer.GetUserInventory(
              { PlayFabId: playFabId },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          const bal = invBuy.data.VirtualCurrency?.[CURRENCY] || 0;
          const alreadyOwned = (invBuy.data.Inventory || []).map(
            (i) => i.ItemId,
          );

          if (alreadyOwned.includes(itemId))
            return btn.reply({
              content: `❌ You already own **${itemId}**!`,
              ephemeral: true,
            });

          if (bal < cost)
            return btn.reply({
              content: `❌ Not enough SR!\nCost: ${formatSR(
                cost,
              )} | You have: ${formatSR(bal)}`,
              ephemeral: true,
            });

          await new Promise((resolve, reject) => {
            PlayFabServer.SubtractUserVirtualCurrency(
              {
                PlayFabId: playFabId,
                VirtualCurrency: CURRENCY,
                Amount: cost,
              },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          await new Promise((resolve, reject) => {
            PlayFabServer.GrantItemsToUser(
              {
                PlayFabId: playFabId,
                ItemIds: [itemId],
                CatalogVersion: "DLC",
              },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          const updated = await new Promise((resolve, reject) => {
            PlayFabServer.GetUserInventory(
              { PlayFabId: playFabId },
              (err, res) => (err ? reject(err) : resolve(res)),
            );
          });

          ownedItems = (updated.data.Inventory || []).map((i) => i.ItemId);
          balance = updated.data.VirtualCurrency?.[CURRENCY] || 0;

          await btn.update({
            embeds: [generateEmbed()],
            components: makeButtons(ownedItems),
          });

          return btn.followUp({
            content: `✅ Purchased **${itemId}** for **${formatSR(cost)} SR**`,
            ephemeral: true,
          });
        } catch (err) {
          console.error("Buy error:", err);
          return btn.reply({
            content: `❌ Error: ${err.message}`,
            ephemeral: true,
          });
        }
      }

      await btn.update({
        embeds: [generateEmbed()],
        components: makeButtons(ownedItems),
      });
    });

    collector.on("end", () => {
      try {
        interaction.client.removeListener("interactionCreate", modalListener);
      } catch {}

      try {
        message.edit({ components: [] });
      } catch {}
    });
  },
};
