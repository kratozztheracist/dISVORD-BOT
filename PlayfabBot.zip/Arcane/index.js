const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, ActivityType, Events, Collection } = require('discord.js');
const { token } = require('./config.json');

// --------------------- Discord Bot ---------------------
const client = new Client({
	intents: [GatewayIntentBits.Guilds]
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');

// Load commands
if (fs.existsSync(commandsPath)) {
	const commandFolders = fs.readdirSync(commandsPath);

	for (const folder of commandFolders) {
		const folderPath = path.join(commandsPath, folder);
		if (!fs.statSync(folderPath).isDirectory()) continue;

		const commandFiles = fs
			.readdirSync(folderPath)
			.filter(file => file.endsWith('.js'));

		for (const file of commandFiles) {
			const command = require(path.join(folderPath, file));
			if (command.data && command.execute) {
				client.commands.set(command.data.name, command);
			}
		}
	}
}

// Ready event
client.once(Events.ClientReady, readyClient => {
	console.log(`Bot logged in as ${readyClient.user.tag} ✅`);
	client.user.setActivity({
		name: 'Playing Arcane Tag',
		type: ActivityType.Playing
	});
});

// Interaction handler
client.on(Events.InteractionCreate, async interaction => {
	if (!interaction.isChatInputCommand()) return;

	const command = client.commands.get(interaction.commandName);
	if (!command) return;

	try {
		// ❌ DO NOT defer here
		await command.execute(interaction);
	} catch (err) {
		console.error(err);

		if (interaction.replied || interaction.deferred) {
			await interaction.followUp({
				content: '❌ Error executing command',
				ephemeral: true
			});
		} else {
			await interaction.reply({
				content: '❌ Error executing command',
				ephemeral: true
			});
		}
	}
});


// Login
client.login(token);
