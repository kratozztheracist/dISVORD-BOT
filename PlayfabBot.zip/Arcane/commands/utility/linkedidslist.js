const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const allowedRoles = [""];
const linkedFile = path.join(__dirname, "..", "data", "linkedAccounts.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("linkedids")
    .setDescription("View all linked PlayFab IDs and their Discord accounts"),

  async execute(interaction) {
    // Role check
    const userRoles = interaction.member.roles.cache.map(r => r.id);
    if (!allowedRoles.some(r => userRoles.includes(r))) {
      return interaction.reply({
        content: "❌ You don't have permission to use this command.",
        ephemeral: true
      });
    }

    // Load linked accounts
    if (!fs.existsSync(linkedFile)) {
      return interaction.reply({
        content: "⚠️ No linked accounts file found.",
        ephemeral: true
      });
    }

    const linkedAccounts = JSON.parse(fs.readFileSync(linkedFile, "utf-8"));
    const entries = Object.entries(linkedAccounts);

    if (entries.length === 0) {
      return interaction.reply({
        content: "ℹ️ No linked accounts found.",
        ephemeral: true
      });
    }

    // Build output lines
    const lines = entries.map(([playFabId, discordId]) => {
      return `\`${playFabId}\` – <@${discordId}>`;
    });

    // Split into chunks to avoid message limit
    const MAX_CHARS = 1800;
    const pages = [];
    let current = "";

    for (const line of lines) {
      if ((current + "\n" + line).length > MAX_CHARS) {
        pages.push(current);
        current = line;
      } else {
        current += (current ? "\n" : "") + line;
      }
    }
    if (current) pages.push(current);

    // Send result
    await interaction.reply({
      content: `📎 **Linked PlayFab Accounts (${entries.length})**\n\n${pages[0]}`,
      ephemeral: true
    });

    // Send remaining pages
    for (let i = 1; i < pages.length; i++) {
      await interaction.followUp({
        content: pages[i],
        ephemeral: true
      });
    }
  }
};
