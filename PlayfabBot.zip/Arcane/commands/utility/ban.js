const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabAdmin = require("playfab-sdk/Scripts/PlayFab/PlayFabAdmin");

const allowedRoles = [""]; 

PlayFab.settings.titleId = ""; 
PlayFab.settings.developerSecretKey = "";  

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bans a player on PlayFab")
    .addStringOption((option) =>
      option.setName("userid").setDescription("The ID of the player to ban").setRequired(true)
    )
    .addIntegerOption((option) =>
      option.setName("hours").setDescription("The ban duration in hours").setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("The reason for the ban").setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const playerId = interaction.options.getString("userid");
    const banDurationInHours = interaction.options.getInteger("hours");
    const banReason = interaction.options.getString("reason");

    try {
      await PlayFabAdmin.BanUsers({
        Bans: [
          {
            PlayFabId: playerId,
            Reason: banReason,
            DurationInHours: banDurationInHours,
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setTitle("Player Banned")
        .setColor(0xFF0000)
        .addFields(
          { name: "User ID", value: playerId, inline: true },
          { name: "Duration", value: `${banDurationInHours} Hours`, inline: true },
          { name: "Reason", value: banReason }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error("Error banning user:", error);

      const errorEmbed = new EmbedBuilder()
        .setTitle("❗ Error Banning User")
        .setColor(0xFFAA00)
        .setDescription(`An error occurred while trying to ban the user.`)
        .addFields(
          { name: "Error", value: error.errorMessage || "Unknown error." }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed] });
    }
  },
};
