const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const allowedRoles = [""];
const dataFile = path.join(__dirname, "..", "data", "linkedAccounts.json"); 

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unlink")
    .setDescription("Unlink your in-game ID from your Discord account."),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(r => r.id);
    if (!allowedRoles.some(r => userRoles.includes(r))) {
      return interaction.reply({ content: "❌ You don't have the required role.", ephemeral: true });
    }

    const discordId = interaction.member.id;

    let linkedAccounts = {};
    if (fs.existsSync(dataFile)) {
      try { linkedAccounts = JSON.parse(fs.readFileSync(dataFile, "utf-8")); }
      catch (err) { console.error("Failed to read linkedAccounts.json:", err); }
    }

    console.log("Using linkedAccounts.json at:", dataFile);
    console.log("Current linked accounts:", linkedAccounts);

    const gameId = Object.keys(linkedAccounts).find(key => linkedAccounts[key] === discordId);
    if (!gameId) {
      return interaction.reply({ content: "⚠️ You have no linked game ID.", ephemeral: true });
    }

    delete linkedAccounts[gameId];

    try {
      if (Object.keys(linkedAccounts).length === 0) fs.unlinkSync(dataFile);
      else fs.writeFileSync(dataFile, JSON.stringify(linkedAccounts, null, 2), "utf-8");

      const embed = new EmbedBuilder()
        .setTitle("🔓 Account Unlinked")
        .setDescription("Your PlayFab account has been successfully unlinked.")
        .addFields(
          { name: "Discord User", value: `${interaction.user}`, inline: true },
          { name: "PlayFab ID", value: gameId, inline: true }
        )
        .setFooter({ text: "You can re-link at any time using /link." })
        .setColor("#e67e22");

      return interaction.reply({ embeds: [embed], ephemeral: true });

    } catch (err) {
      console.error(err);
      return interaction.reply({ content: "❌ Failed to unlink your ID.", ephemeral: true });
    }
  }
};
