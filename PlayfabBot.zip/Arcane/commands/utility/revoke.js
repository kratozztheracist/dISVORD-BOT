const { SlashCommandBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");
const allowedRoles = [""]; 

PlayFab.settings.titleId = ""; 
PlayFab.settings.developerSecretKey =
  ""; 

module.exports = {
  data: new SlashCommandBuilder()
    .setName("revoke")
    .setDescription("revokes a cosmetic item from the user")
    .addStringOption((option) =>
      option
        .setName("instanceid")
        .setDescription("the instance ID of the item to revoke")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("userid")
        .setDescription("the ID of the user")
        .setRequired(true)
    ),

  async execute(interaction) {

    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply("You don't have the required role to use this command.");
    }

    const instanceId = interaction.options.getString("instanceid");
    const playFabId = interaction.options.getString("playfabid");

    try {
      const response = await PlayFabServer.RevokeInventoryItem({
        PlayFabId: playFabId,
        ItemInstanceId: instanceId
      });

      if (response && response.code !== 200) {
        console.error("PlayFab API Error:", response);
        return interaction.reply(`Error revoking cosmetic: ${response.status}`);
      }

      await interaction.reply(`Successfully revoked item ${instanceId} from user ${playFabId}.`);
    } catch (error) {
      console.error("Error revoking cosmetic:", error);
      await interaction.reply(`Failed to revoke item: ${error.message}`);
    }
  },
};
