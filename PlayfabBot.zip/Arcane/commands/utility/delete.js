const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabAdmin = require("playfab-sdk/Scripts/PlayFab/PlayFabAdmin");

const allowedRoles = [""];

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("delete")
    .setDescription("Deletes a player's account from PlayFab.")
    .addStringOption((option) =>
      option.setName("userid").setDescription("The ID of the player to delete").setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const playerId = interaction.options.getString("userid");

    try {
      const response = await PlayFabAdmin.DeletePlayer({ PlayFabId: playerId });

      console.log("PlayFab API Response:", response);

      if (response && response.code !== 200) {
        console.error("PlayFab API Error:", response);

        const errorEmbed = new EmbedBuilder()
          .setTitle("Failed to Delete Player")
          .setColor(0xFFAA00)
          .addFields(
            { name: "Player ID", value: playerId },
            { name: "Status Code", value: `${response.code}` },
            { name: "Status", value: response.status || "Unknown" }
          )
          .setTimestamp();

        return interaction.reply({ embeds: [errorEmbed] });
      }

      const successEmbed = new EmbedBuilder()
        .setTitle("Player Account Deleted")
        .setColor(0xFF0000)
        .addFields({ name: "Player ID", value: playerId })
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });

    } catch (error) {
      console.error("Error deleting player:", error);

      const errorEmbed = new EmbedBuilder()
        .setTitle("❗ Error Deleting Player")
        .setColor(0xFF5500)
        .setDescription(`An error occurred while trying to delete the player.`)
        .addFields(
          { name: "Player ID", value: playerId },
          { name: "Error", value: error.message || "Unknown error." }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed] });
    }
  },
};
