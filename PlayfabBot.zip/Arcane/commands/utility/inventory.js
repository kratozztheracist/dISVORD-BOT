const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");

const allowedRoles = [""];

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("inventory")
    .setDescription("Displays a user's PlayFab inventory.")
    .addStringOption((option) =>
      option.setName("userid").setDescription("The PlayFab ID of the user.").setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const userid = interaction.options.getString("userid");

    PlayFabServer.GetUserInventory({ PlayFabId: userid }, async (error, result) => {
      if (error) {
        console.error("PlayFab error:", error);

        const errorEmbed = new EmbedBuilder()
          .setTitle("❗ Inventory Retrieval Failed")
          .setColor(0xFF0000)
          .setDescription(`Failed to retrieve inventory: ${error.errorMessage || error}`)
          .setTimestamp();

        return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
      }

      const inventory = result?.data?.Inventory;

      if (!inventory || inventory.length === 0) {
        const emptyEmbed = new EmbedBuilder()
          .setTitle("Empty Inventory")
          .setColor(0xCCCCCC)
          .setDescription(`User **${userid}** has no items in their inventory.`)
          .setTimestamp();

        return interaction.reply({ embeds: [emptyEmbed], ephemeral: true });
      }

      const embeds = [];
      const chunkSize = 10; 

      for (let i = 0; i < inventory.length; i += chunkSize) {
        const chunk = inventory.slice(i, i + chunkSize);
        const embed = new EmbedBuilder()
          .setTitle(`Inventory for ${userid}`)
          .setColor(0x00AAFF)
          .setTimestamp();

        chunk.forEach(item => {
          embed.addFields({
            name: item.DisplayName || item.ItemId,
            value: `**ItemId:** \`${item.ItemId}\`\n**InstanceId:** \`${item.ItemInstanceId}\``,
            inline: false,
          });
        });

        embeds.push(embed);
      }

      await interaction.reply({ content: `Inventory contains **${inventory.length}** item(s).`, ephemeral: true });

      for (const embed of embeds) {
        await interaction.followUp({ embeds: [embed], ephemeral: true });
      }
    });
  },
};
