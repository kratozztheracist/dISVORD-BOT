const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const allowedRoles = [""];
const dataFile = path.join(__dirname, "..", "data", "linkedAccounts.json"); // central path

module.exports = {
  data: new SlashCommandBuilder()
    .setName("link")
    .setDescription("Link your in-game ID to your Discord account.")
    .addStringOption(option =>
      option.setName("userid")
            .setDescription("Your in-game player ID")
            .setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(r => r.id);
    if (!allowedRoles.some(r => userRoles.includes(r))) {
      return interaction.reply({ content: "❌ You don't have the required role.", ephemeral: true });
    }

    const userid = interaction.options.getString("userid");
    const discordId = interaction.member.id;

    // Always read latest file
    let linkedAccounts = {};
    if (fs.existsSync(dataFile)) {
      try { linkedAccounts = JSON.parse(fs.readFileSync(dataFile, "utf-8")); }
      catch(err) { console.error("Failed to read linkedAccounts.json:", err); }
    }

    console.log("Using linkedAccounts.json at:", dataFile);
    console.log("Current linked accounts:", linkedAccounts);

    // Prevent linking same game ID to another user
    if (linkedAccounts[userid] && linkedAccounts[userid] !== discordId) {
      let otherUserName = userid;
      try {
        const user = await interaction.client.users.fetch(linkedAccounts[userid]);
        otherUserName = user.tag;
      } catch {}
      return interaction.reply({ content: `❌ Game ID \`${userid}\` is already linked to user ${otherUserName}.`, ephemeral: true });
    }

    // Remove previous ID linked to this user
    for (const key of Object.keys(linkedAccounts)) {
      if (linkedAccounts[key] === discordId && key !== userid) delete linkedAccounts[key];
    }

    // Link new ID
    linkedAccounts[userid] = discordId;

    try {
      fs.writeFileSync(dataFile, JSON.stringify(linkedAccounts, null, 2), "utf-8");

      // === ✅ SUCCESS EMBED (converted from your Python example) ===
      const embed = new EmbedBuilder()
        .setTitle("✅ Account Linked!")
        .setDescription("Your PlayFab account has been linked.")
        .addFields(
          { name: "Discord User", value: `${interaction.user}`, inline: true },
          { name: "PlayFab ID", value: userid, inline: true }
        )
        .setFooter({ text: "You can now use /shop and /playfabinfo." })
        .setColor("#2ecc71");

      return interaction.reply({ embeds: [embed], ephemeral: true });
      // ============================================================

    } catch (err) {
      console.error(err);
      return interaction.reply({ content: "❌ Failed to link your ID.", ephemeral: true });
    }
  }
};
