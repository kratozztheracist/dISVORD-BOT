const { SlashCommandBuilder } = require("discord.js");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");
const fs = require("fs");
const path = require("path");

const allowedRoles = [""];
const linkedFile = path.join(__dirname, "..", "data", "linkedAccounts.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("playfablookup")
    .setDescription("Lookup PlayFab info using a Discord user ID.")
    .addStringOption(option =>
      option.setName("discordid")
        .setDescription("The Discord user ID to lookup")
        .setRequired(true)
    ),

  async execute(interaction) {

    // ---- FAST VALIDATION (NO DEFER YET) ----
    const userRoles = interaction.member.roles.cache.map(r => r.id);
    if (!allowedRoles.some(r => userRoles.includes(r))) {
      return interaction.reply({
        content: "❌ You don't have the required role.",
        ephemeral: true
      });
    }

    const inputDiscordId = interaction.options.getString("discordid")?.trim();
    if (!inputDiscordId) {
      return interaction.reply({
        content: "❌ You must provide a valid Discord ID.",
        ephemeral: true
      });
    }

    // Load linkedAccounts.json
    let linkedAccounts = {};
    if (fs.existsSync(linkedFile)) {
      linkedAccounts = JSON.parse(fs.readFileSync(linkedFile, "utf-8"));
    }

    const playFabId = Object.keys(linkedAccounts).find(
      key => linkedAccounts[key] === inputDiscordId
    );

    if (!playFabId) {
      return interaction.reply({
        content: `⚠️ No linked PlayFab ID found for Discord ID \`${inputDiscordId}\`.`,
        ephemeral: true
      });
    }

    // ---- SLOW WORK STARTS HERE ----
    await interaction.deferReply({ ephemeral: true });

    try {
      const accountInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserAccountInfo({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const inventoryInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserInventory({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const banInfo = await new Promise((resolve, reject) => {
        PlayFabServer.GetUserBans({ PlayFabId: playFabId }, (err, res) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      const userInfo = accountInfo?.data?.UserInfo;
      const currency = inventoryInfo?.data?.VirtualCurrency || {};
      const bans = banInfo?.data?.BanData || [];

      const activeBan = bans.find(b => !b.Revoked);
      const banStatus = activeBan
        ? `🚫 BANNED - Reason: ${activeBan.Reason || "No reason provided"}`
        : `✅ Not Banned`;

      let discordUserTag = inputDiscordId;
      try {
        const user = await interaction.client.users.fetch(inputDiscordId);
        discordUserTag = user.tag;
      } catch {}

      const output = `📋 PlayFab Info for **${discordUserTag}**

🆔 **PlayFab ID:** \`${playFabId}\`
📅 **Account Created:** ${new Date(userInfo.Created).toLocaleString()}
💰 **Currency:** ${
        Object.entries(currency)
          .map(([c, a]) => `${c}: ${a.toLocaleString()}`)
          .join(", ") || "None"
      }
🔒 **Ban Status:** ${banStatus}
`;

      await interaction.editReply({ content: output });

    } catch (err) {
      console.error("PlayFab lookup error:", err);
      await interaction.editReply({
        content: "❌ Failed to fetch PlayFab info. Please check the ID."
      });
    }
  },
};
