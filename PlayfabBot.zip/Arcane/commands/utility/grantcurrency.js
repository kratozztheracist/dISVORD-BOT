const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");

const allowedRoles = [""];

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("give")
    .setDescription("Gives virtual currency to a user.")
    .addStringOption((option) =>
      option.setName("userid").setDescription("The PlayFab ID of the user.").setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("currencycode").setDescription("Currency code (e.g., SR)").setRequired(true)
    )
    .addIntegerOption((option) =>
      option.setName("amount").setDescription("Amount of currency to give.").setRequired(true)
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const playerId = interaction.options.getString("userid");
    const currencyCode = interaction.options.getString("currencycode").toUpperCase();
    const amount = interaction.options.getInteger("amount");

    try {
      const response = await PlayFabServer.AddUserVirtualCurrency({
        PlayFabId: playerId,
        VirtualCurrency: currencyCode,
        Amount: amount,
      });

      console.log("PlayFab API Response:", response);

      if (response && response.code !== 200) {
        console.error("PlayFab API Error:", response);

        const errorEmbed = new EmbedBuilder()
          .setTitle("Failed to Grant Currency")
          .setColor(0xFFAA00)
          .addFields(
            { name: "Player ID", value: playerId },
            { name: "Currency", value: currencyCode },
            { name: "Amount", value: `${amount}` },
            { name: "Status Code", value: `${response.code}` },
            { name: "Status", value: response.status || "Unknown" }
          )
          .setTimestamp();

        return interaction.reply({ embeds: [errorEmbed] });
      }

      const successEmbed = new EmbedBuilder()
        .setTitle("Currency Granted")
        .setColor(0x00CC99)
        .addFields(
          { name: "Player ID", value: playerId },
          { name: "Currency", value: currencyCode },
          { name: "Amount Granted", value: `${amount}` }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });

    } catch (error) {
      console.error("Error granting currency:", error);

      const errorEmbed = new EmbedBuilder()
        .setTitle("❗ Error Granting Currency")
        .setColor(0xFF5500)
        .addFields(
          { name: "Player ID", value: playerId },
          { name: "Currency", value: currencyCode },
          { name: "Amount", value: `${amount}` },
          { name: "Error", value: error.message || "Unknown error." }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed] });
    }
  },
};
