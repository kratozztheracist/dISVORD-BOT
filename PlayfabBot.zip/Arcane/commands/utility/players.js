const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");

const allowedRoles = [""];
PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey = "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("playercount")
    .setDescription("Displays the total number of players in your PlayFab title."),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasRequiredRole = allowedRoles.some(roleId => userRoles.includes(roleId));

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const fetchAllPlayersInSegment = async (segmentId) => {
      let totalPlayers = 0;
      let continuationToken = null;

      do {
        const request = {
          SegmentId: segmentId,
          ContinuationToken: continuationToken || undefined,
        };

        const result = await new Promise((resolve, reject) => {
          PlayFabServer.GetPlayersInSegment(request, (err, res) => {
            if (err) return reject(err);
            resolve(res);
          });
        });

        const players = result?.data?.PlayerProfiles || [];
        totalPlayers += players.length;

        continuationToken = result?.data?.ContinuationToken || null;
      } while (continuationToken);

      return totalPlayers;
    };

    try {
      const segmentId = ""; 
      const imageUrl = "";

      const count = await fetchAllPlayersInSegment(segmentId);

      const embed = new EmbedBuilder()
        .setTitle("Total Player Count")
        .setDescription(`There are **${count}** players.`)
        .setColor(0x00BFFF)
        .setThumbnail(imageUrl) 
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("PlayFab Error:", error);
      await interaction.editReply("❌ Failed to fetch player count from PlayFab.");
    }
  },
};
