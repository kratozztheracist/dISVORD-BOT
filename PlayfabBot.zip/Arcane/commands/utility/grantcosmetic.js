const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const PlayFab = require("playfab-sdk/Scripts/PlayFab/PlayFab");
const PlayFabServer = require("playfab-sdk/Scripts/PlayFab/PlayFabServer");

const allowedRoles = [""];

PlayFab.settings.titleId = "";
PlayFab.settings.developerSecretKey =
  "";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("grant")
    .setDescription("Grants a cosmetic item to a user.")
    .addStringOption((option) =>
      option
        .setName("userid")
        .setDescription("The PlayFab ID of the user.")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("item")
        .setDescription("The cosmetic item ID to grant.")
        .setRequired(true),
    ),

  async execute(interaction) {
    const userRoles = interaction.member.roles.cache.map((role) => role.id);
    const hasRequiredRole = allowedRoles.some((roleId) =>
      userRoles.includes(roleId),
    );

    if (!hasRequiredRole) {
      return interaction.reply({
        content: "❌ You don't have the required role to use this command.",
        ephemeral: true,
      });
    }

    const playerId = interaction.options.getString("userid");
    const cosmeticCode = interaction.options.getString("item");

    try {
      const response = await new Promise((resolve, reject) => {
        PlayFabServer.GrantItemsToUser(
          {
            PlayFabId: playerId,
            ItemIds: [cosmeticCode],
            CatalogVersion: "DLC",
          },
          (error, result) => {
            if (error) return reject(error);
            resolve(result);
          },
        );
      });

      console.log("PlayFab API Response:", JSON.stringify(response, null, 2));

      const grantedItems =
        response.data?.ItemGrantResults?.map((item) => `• ${item.ItemId}`).join(
          "\n",
        ) || "No item details";

      const successEmbed = new EmbedBuilder()
        .setTitle("Cosmetic Granted")
        .setColor(0x00ff99)
        .addFields(
          { name: "Player ID", value: playerId },
          { name: "Granted Item", value: grantedItems },
        )
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error("Error granting cosmetic:", error);

      const errorEmbed = new EmbedBuilder()
        .setTitle("❗ Error Granting Cosmetic")
        .setColor(0xff5500)
        .setDescription(
          "An error occurred while trying to grant the cosmetic item.",
        )
        .addFields(
          { name: "Player ID", value: playerId },
          { name: "Cosmetic Code", value: cosmeticCode },
          {
            name: "Error",
            value: error.errorMessage || error.message || "Unknown error.",
          },
        )
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed] });
    }
  },
};
